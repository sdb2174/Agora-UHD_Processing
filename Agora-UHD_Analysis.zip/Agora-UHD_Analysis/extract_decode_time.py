# Extracts the decode time data from the file 'filename.txt' in microseconds.

# Read the data from the file
root = 'Time_S_M16_C663_DI3'
extractor = 'timeresult.txt'
filename = 'S-M64-C333-SNR30-DI3.csv'

with open('Time_S_M64_C663_DI25/timeresult.txt', 'r') as file:
    lines = file.readlines()

last_column_data = [line.split()[-1] for line in lines]

with open('Time_S_M64_C663_DI25/S-M64-C663-SNRneg10-DI25.csv', 'w') as csv_file:
    csv_file.write("\n".join(last_column_data))
