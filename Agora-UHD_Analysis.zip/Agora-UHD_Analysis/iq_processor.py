import csv

# Read the CSV file
with open('IQ_stream.csv', 'r') as file:
    reader = csv.reader(file)
    data = list(reader)

# Process the data to remove quotes and parentheses
processed_data = [f"{float(row[0])}, {float(row[1])}" for row in data]

# Write the processed data to a new CSV file
with open('IQ_stream_proc.csv', 'w') as file:
    file.write('\n'.join(processed_data))